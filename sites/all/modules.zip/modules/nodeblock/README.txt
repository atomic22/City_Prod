Nodeblock - Use nodes as blocks

1. Install the Nodeblock module the usual way at admin/build/modules.
2. Edit the content type that you wish to use as a block. In most situations you
   would create a simple content type named Block to use as your custom blocks,
   but you shouldn't feel limited to just this usage.  Any type of node, using
   any type of field may be used as a nodeblock.
3. Select the Enabled radio button on the Available as block field.
4. Create block nodes and watch them populate your block list!




