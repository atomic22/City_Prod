<?php
?>
<div class="dashboard-entry clearfix">
  <div class="dashboard-text">
    <div class="dashboard-link">
      <?php print $link['title']; ?>
    </div>
    <div class="description">
      <?php print $link['description']; ?>
    </div>
  </div>
</div>
