Theme: Mobile jQuery
Author: Jason Savino <http://drupal.org/user/411241>

INSTALLATION
===========

 1. Download mobile_jquery from http://drupal.org/project/mobile_jquery

 2. Unpack the downloaded file, take the entire mobile_jquery folder and place
     it in your Drupal installation.
     
 3. Now build your own sub-theme by reading the STARTER/README.txt file.
 
 4. Log in as an administrator on your Drupal site and go to the Appearance page
    at admin/appearance. You will see your sub-theme theme listed under the Disabled
    Themes heading with links on how to create your own sub-theme.
    
*NOTE: The mobile_jquery theme has an entry in the mobile_jquery.info file, 'hidden = 1'
             This setting hides the theme from the admin/appearance page. It is recommended
             that you create a sub-theme and not use this theme directly. If you wish to do
             simply change the setting to 'hidden = 0'.
