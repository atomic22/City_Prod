<div<?php print $attributes; ?>>
  <div<?php print $content_attributes; ?>>
    <nav id="footer-nav" class="footer-nav clearfix"><?php print render($footer_menu); ?></nav>
    <section class="clearfix"><?php print $content; ?></section>
  </div>
</div>