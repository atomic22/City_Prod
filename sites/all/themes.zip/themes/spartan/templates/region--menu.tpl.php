
  <div<?php print $content_attributes; ?>>
    <nav class="navigation">
      <?php print render($dropdown_menu); ?>
    </nav>
    <?php print $content; ?>
  </div>

